Matthew Dorfmann - 43274109
William Hsiao - 32574113
Matthew Arnold - 82417106
Rob Larm

There are 7 files in the .zip archive:

UML_ui().asta - the uml class diagram of the UI, which was later added to schoolViewerClassDiagram.asta

Class Diagram0.asta - the uml class diagram largely composing the server-side of the final diagram

SchoolViewerClassDiagram.asta - the final uml class diagram.  This contains the class diagram for the project AND the sequence diagram for the project

ClassDiagramFinal.png - The final class diagram in PNG form

SequenceDiagramFinal.png - The final sequence diagram in PNG form

NewDoc 11.pdf - a sheet on which we were originally working out certain classes that we would need

README.txt - the readme file